# Financial graph items
from pandas_datareader import data
from bokeh.plotting import figure, show, output_file
from bokeh.embed import components
from bokeh.resources import CDN
import datetime
from dateutil.relativedelta import relativedelta

def generate_graph(lcname, liqtr = 1, liyr = 2016, lcsource = "yahoo"):
    # Assume that the year and quarter will be passed in as integers
    # Set dates
    lihrs_conv = 12 * 60 * 60 * 1000 # Graph is in milliseconds
    if liqtr == 1:
        limonth = 1
    elif liqtr == 2:
        limonth = 4
    elif liqtr == 3:
        limonth = 7
    else:
        limonth = 10

    ldstart = datetime.datetime(liyr, limonth, 1)
    ldend = ldstart + relativedelta(months = 3, days = -1)

    # Import data

    lcsource = "yahoo"
    try:
        df = data.DataReader(name = lcname, data_source = lcsource, start = ldstart, end = ldend)


        # Create columns for plotting
        def status_ind(open, close):
            if open < close:
                value = "increase"
            elif open > close:
                value = "decrease"
            else:
                value = "equal"

            return value

        df["Status"] = [status_ind(c,o) for c, o in zip(df.Close, df.Open)]
        df["Middle"] = (df.Open + df.Close) / 2
        df["Height"] = abs(df.Open - df.Close)


        # Generate plot
        loplot = figure(x_axis_type = "datetime", x_axis_label = "Date", y_axis_label = "Stock Price", width = 1000, height = 300, sizing_mode = "scale_width")
        loplot.title.text = "Financial Candlestick Chart for " + lcname.upper() + " in Q" + str(liqtr) + ", " + str(liyr) + ": " + ldstart.strftime("%D-%m-%Y to ") + ldend.strftime("%D-%m-%Y")
        loplot.title.align = "center"
        loplot.title.text_font_size = "16pt"
        loplot.xaxis.axis_label_text_font_style = "bold"
        loplot.yaxis.axis_label_text_font_style = "bold"
        loplot.grid.grid_line_alpha = 0.3

        loplot.segment(df.index, df.High, df.index, df.Low, line_color = "black")

        loplot.rect(df.index[df.Status != "decrease"], df.Middle[df.Status != "decrease"], lihrs_conv, df.Height[df.Status != "decrease"],
                    fill_color = "#00c200", line_color = "black")

        loplot.rect(df.index[df.Status == "decrease"], df.Middle[df.Status == "decrease"], lihrs_conv, df.Height[df.Status == "decrease"],
                    fill_color = "#e50600", line_color = "black")

        # Generate components to pass to web browser
        script, div = components(loplot)
        cdn_js = CDN.js_files
        cdn_css = CDN.css_files

        return (script, div, cdn_css[0], cdn_js[0])

    except:
        lctxt = "Could not fetch data for company symbol " + lcname + " for Q" + str(liqtr) + ", " + str(liyr) +  "."
        return False, lctxt
