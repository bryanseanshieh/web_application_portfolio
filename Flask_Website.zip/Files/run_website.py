# Import libraries
from flask import Flask, render_template, request
from generate_graph import generate_graph

app = Flask(__name__)

# Main page
@app.route('/')
def home():
    return render_template("home.html")

# About page
@app.route('/about')
def about():
    return render_template("about.html")

# Picture filter project from HTML / CSS class # (object):
# Note that the original project from codepen has separate CSS and Javascript
# files that need to be added to and called from a "static folder"
@app.route('/picture_filter')
def init_picture_filter():
    return render_template("filter_project.html")

@app.route('/financial_project')
def financial_project():
    return render_template("financial_graph.html")


@app.route('/financial_project/graph', methods = ['POST'])
def financial_graph():
    # Get information from server request
    if request.method == "POST":
        try:
            company = request.form["company"]
            qtr = int(request.form["quarter"])
            yr = int(request.form["year"])
            fg_items = generate_graph(company, qtr, yr)

            if len(fg_items) == 0 or fg_items[0] == False:
                return render_template("financial_graph.html", err_msg = fg_items[1])
            else:
                return render_template("financial_graph.html",
                    fg_script = fg_items[0],
                    fg_div = fg_items[1],
                    cdn_css = fg_items[2],
                    cdn_js = fg_items[3]
                    )

        except:
            err_msg = "There was a problem reading user inputs. Please make sure you enter the right information"
            return render_template("financial_graph.html", err_msg = err_msg)





    return render_template("financial_graph.html")


if __name__ == "__main__":
    app.run(debug = True)
