// The javascript supports the ability to load an image and apply filters as per user specifications.

//Declare global variables
var userImg = null;
var imgRed = null;
var imgGreen = null;
var imgPurple = null;
var imgGray = null;
var imgFrench = null;
var imgHungary =  null;
var imgJapan = null;
var imgRainbow = null;
var imgBlur = null;

function loadImage(){
  //Load image
  imgfile = document.getElementById("inputfile");
  canvas = document.getElementById("cvs");
  userImg = new SimpleImage(imgfile);
  userImg.drawTo(canvas);
    
}

function doRed(){
  //Shell function to appy red filter onto image.
  var canvas = document.getElementById("cvs");

  if(!isImageLoaded(userImg)){
    alert('Filter image was not properly loaded.'); //Check image
    return;
  }
  redFilter();
  clearCanvas();
  imgRed.drawTo(canvas);
}

function redFilter(){
  imgRed = new SimpleImage(userImg);
  // Make the image look red
  for(var pxl of imgRed.values()){
    makePxlRed(pxl);
  }
}

function doGreen(){
  //Shell function to appy red filter onto image.
  var canvas = document.getElementById("cvs");

  if(!isImageLoaded(userImg)){
    alert('Filter image was not properly loaded.'); //Check image
    return;
  }
  greenFilter();
  clearCanvas();
  imgGreen.drawTo(canvas);
}

function greenFilter(){
  imgGreen = new SimpleImage(userImg);
  // Make the image look green
  for(var pxl of imgGreen.values()){
    makePxlGreen(pxl);
  }
}

function doPurple(){
  //Shell function to appy red filter onto image.
  var canvas = document.getElementById("cvs");

  if(!isImageLoaded(userImg)){
    alert('Filter image was not properly loaded.'); //Check image
    return;
  }
  purpleFilter();
  clearCanvas();
  imgPurple.drawTo(canvas);
}

function purpleFilter(){
  imgPurple = new SimpleImage(userImg);
  // Make the image look purple
  for(var pxl of imgPurple.values()){
    makePxlPurple(pxl);
  }
}

function doGrayScale(){
  //Load image with grayScale filter applied
  var canvas = document.getElementById("cvs");
  
  if(!isImageLoaded(userImg)){
    alert('Filter image was not properly loaded.'); //Check image
    return;
  }
  grayScale();
  clearCanvas();
  imgGray.drawTo(canvas);
}

function grayScale(){
  imgGray = new SimpleImage(userImg);
  for(var pxl of imgGray.values()){
    makePxlGray(pxl);
  }
}

function FrenchFlag(){
  //Filter image with French flag colors (red white blue vertical)
  var canvas = document.getElementById("cvs");  
  if(!isImageLoaded(userImg)){
     alert('Filter image was not properly loaded.'); //Check image
    return;
  }
  FrenchColors();
  clearCanvas();
  imgFrench.drawTo(canvas);
}

function FrenchColors(){
  imgFrench = new SimpleImage(userImg);
  for(var pxl of imgFrench.values()){
    
    if(pxl.getX() < imgFrench.getWidth() / 3){
     makePxlRed(pxl);
    }
    else if (pxl.getX() >= imgFrench.getWidth() / 3 * 2){
      makePxlBlue(pxl);
    }
    else{
        makePxlGray(pxl);
    }
  }
}

function HungaryFlag(){
  //Filter image with Hungary flag colors (red white green horizontal)
  var canvas = document.getElementById("cvs");  
  if(!isImageLoaded(userImg)){
     alert('Filter image was not properly loaded.'); //Check image
    return;
  }
  HungaryColors();
  clearCanvas();
  imgHungary.drawTo(canvas);
}

function HungaryColors(){
  imgHungary = new SimpleImage(userImg);
  for(var pxl of imgHungary.values()){
    
    if(pxl.getY() < imgHungary.getHeight() / 3){
      makePxlRed(pxl);
    }
    else if (pxl.getY() >= imgHungary.getHeight() / 3 * 2){
     makePxlGreen(pxl);
    }
    else{
      makePxlGray(pxl);
    }
  }
}

function JapanFlag(){
  //Filter image with Japan flag colors
  var canvas = document.getElementById("cvs");  
  if(!isImageLoaded(userImg)){
     alert('Filter image was not properly loaded.'); //Check image
    return;
  }
  JapanColors();
  clearCanvas();
  imgJapan.drawTo(canvas);
}

function JapanColors(){
  imgJapan = new SimpleImage(userImg);
    
  var radius = 0.35 * Math.min(imgJapan.getWidth(),imgJapan.getHeight());
 
  for(var pxl of imgJapan.values()){
    if(Math.pow(pxl.getX() - imgJapan.getWidth() / 2,2) + Math.pow(pxl.getY() - imgJapan.getHeight() / 2,2) < Math.pow(radius,2)){
      makePxlRed(pxl);
    }
    else{
      makePxlGray(pxl);   
    }
  }
}

function RainbowFilter(){
  //Filter image with Rainbow colors
  var canvas = document.getElementById("cvs");  
  if(!isImageLoaded(userImg)){
     alert('Filter image was not properly loaded.'); //Check image
    return;
  }
  Rainbow();
  clearCanvas();
  imgRainbow.drawTo(canvas);
}

function Rainbow(){
  imgRainbow = new SimpleImage(userImg);
  for(var pxl of imgRainbow.values()){
    if(pxl.getY() < imgRainbow.getHeight() / 7){
      makePxlRed(pxl);
    }
    else if (pxl.getY() >= imgRainbow.getHeight() / 7 && pxl.getY() < imgRainbow.getHeight() / 7 * 2){
      makePxlOrange(pxl);
    }
    else if (pxl.getY() >= imgRainbow.getHeight() / 7 * 2 && pxl.getY() < imgRainbow.getHeight() / 7 * 3){
      makePxlYellow(pxl);
    }    
    else if (pxl.getY() >= imgRainbow.getHeight() / 7 * 3 && pxl.getY() < imgRainbow.getHeight() / 7 * 4){
      makePxlGreen(pxl);
    }
     else if (pxl.getY() >= imgRainbow.getHeight() / 7 * 4 && pxl.getY() < imgRainbow.getHeight() / 7 * 5){
      makePxlBlue(pxl);
    }
    else if (pxl.getY() >= imgRainbow.getHeight() / 7 * 5 && pxl.getY() < imgRainbow.getHeight() / 7 * 6){
      makePxlPurple(pxl);
    }       
    else{
      makePxlIndigo(pxl);     
    }
  }
}

function BlurFilter(){
  //Blur image
  var canvas = document.getElementById("cvs");  
  if(!isImageLoaded(userImg)){
     alert('Filter image was not properly loaded.'); //Check image
    return;
  }
  Blur();
  clearCanvas();
  imgBlur.drawTo(canvas);
}

function Blur(){
    var radius;
    var angle;
    var xNew;
    var yNew;
    
    imgBlur = new SimpleImage(userImg);
    
    for(var pxl of userImg.values()){
        
        if (Math.random() > 0.5){
            radius = 10*Math.random();
            angle = 360 * Math.random();
            xNew = Math.min(Math.max(pxl.getX() + Math.round(radius * Math.cos(angle)), 0), userImg.getWidth() - 1);
            yNew = Math.min(Math.max(pxl.getY() + Math.round(radius * Math.sin(angle)), 0), userImg.getHeight() - 1);
            imgBlur.setPixel(pxl.getX(),pxl.getY(),userImg.getPixel(xNew,yNew));
        }
        else{
            imgBlur.setPixel(pxl.getX(),pxl.getY(),pxl);
        }
    }
}

function isImageLoaded(img){
  //Helper function to determine that the input has an image and has been loaded
  if(img == null || !img.complete()){
    return false;
  }
  else{
    return true;
  }
}

function makePxlRed(pixel){
  // Make a pixel red as per algorithm specifications
    var pxlAvg = Math.round((pixel.getRed() + pixel.getBlue() + pixel.getGreen()) / 3);
    
    if(pxlAvg < 128){
      pixel.setRed(pxlAvg * 2);
      pixel.setBlue(0);
      pixel.setGreen(0);
    }
    else{
      pixel.setRed(255);
      pixel.setBlue(pxlAvg * 2 - 255);
      pixel.setGreen(pxlAvg * 2 - 255);
    }
}

function makePxlOrange(pixel){
  // Make a pixel red as per algorithm specifications
    var pxlAvg = Math.round((pixel.getRed() + pixel.getBlue() + pixel.getGreen()) / 3);
    
    if(pxlAvg < 128){
      pixel.setRed(pxlAvg * 2);
      pixel.setBlue(0);
      pixel.setGreen(pxlAvg * 0.8);
    }
    else{
      pixel.setRed(255);
      pixel.setBlue(pxlAvg * 2 - 255);
      pixel.setGreen(pxlAvg * 1.2 - 51);
    }
}

function makePxlYellow(pixel){
  // Make a pixel red as per algorithm specifications
    var pxlAvg = Math.round((pixel.getRed() + pixel.getBlue() + pixel.getGreen()) / 3);
    
    if(pxlAvg < 128){
      pixel.setRed(pxlAvg * 2);
      pixel.setBlue(0);
      pixel.setGreen(pxlAvg * 2);
    }
    else{
      pixel.setRed(255);
      pixel.setBlue(pxlAvg * 2 - 255);
      pixel.setGreen(255);
    }
}

function makePxlGreen(pixel){
  // Make a pixel red as per algorithm specifications
    var pxlAvg = Math.round((pixel.getRed() + pixel.getBlue() + pixel.getGreen()) / 3);
    
     if(pxlAvg < 128){
      pixel.setRed(0);
      pixel.setBlue(0);
      pixel.setGreen(pxlAvg * 2);
    }
    else{
      pixel.setRed(pxlAvg * 2 - 255);
      pixel.setBlue(pxlAvg * 2 - 255);
      pixel.setGreen(255);
    }
}

function makePxlBlue(pixel){
  // Make a pixel red as per algorithm specifications
    var pxlAvg = Math.round((pixel.getRed() + pixel.getBlue() + pixel.getGreen()) / 3);
    
    if(pxlAvg < 128){
       pixel.setRed(0);
       pixel.setBlue(pxlAvg * 2);
       pixel.setGreen(0);
    }
    else{
      pixel.setRed(pxlAvg * 2 - 255);
      pixel.setBlue(255);
      pixel.setGreen(pxlAvg * 2 - 255);
    }
}

function makePxlPurple(pixel){
  // Make a pixel red as per algorithm specifications
    var pxlAvg = Math.round((pixel.getRed() + pixel.getBlue() + pixel.getGreen()) / 3);
    
    if(pxlAvg < 128){
       pixel.setRed(0.8 * pxlAvg);
       pixel.setBlue(pxlAvg * 2);
       pixel.setGreen(0);
    }
    else{
      pixel.setRed(pxlAvg * 1.2 - 51);
      pixel.setBlue(255);
      pixel.setGreen(pxlAvg * 2 - 255);
    }
}

function makePxlIndigo(pixel){
  // Make a pixel red as per algorithm specifications
    var pxlAvg = Math.round((pixel.getRed() + pixel.getBlue() + pixel.getGreen()) / 3);
    
    if(pxlAvg < 128){
       pixel.setRed(1.6 * pxlAvg);
       pixel.setBlue(1.6 * pxlAvg);
       pixel.setGreen(0);
    }
    else{
      pixel.setRed(pxlAvg * 0.4 + 153);
      pixel.setBlue(pxlAvg * 0.4 + 153);
      pixel.setGreen(pxlAvg * 2 - 255);
    }
}

function makePxlGray(pixel){
   var pxlAvg = Math.round((pixel.getRed() + pixel.getBlue() + pixel.getGreen()) / 3);
    
      pixel.setRed(pxlAvg);
      pixel.setBlue(pxlAvg);
      pixel.setGreen(pxlAvg);  
}

function Reset(){
  var imgfile = document.getElementById("inputfile");
  if(!isImageLoaded(userImg)){
     alert('Filter image was not properly loaded.'); //Check image
    return;
  }  
  clearCanvas();
  userImg.drawTo(canvas);  
}

function clearCanvas(){
  var canvas = document.getElementById("cvs");
    var ctx = canvas.getContext("2d");
  ctx.clearRect(0,0,canvas.width,canvas.height);
}