// The javascript supports the ability to load an image and apply filters as per user specifications.

var controller = (function(){

    var DOMstrings = {
        load: "#input__file",
        reset:  "#reset__btn",
        filterbtn: "#filter__btn",
        filtersel: "#filter__select",
        img_id: "#output",
        canvas: "#cvs"
    }

    var initialize = function(){

        // Add event listeners
        document.querySelector(DOMstrings.load).addEventListener('change', function(event){
            ctrLoad(event);
        });
        document.querySelector(DOMstrings.filterbtn).addEventListener('click', ctrFilter);
    }

    function ctrLoad(evt){
        // Get image from input filter
        console.log("Fetching image...");

        if (evt){

            var inputfiles = evt.target.files;  // Get files

            /* Create a file reader object and set the "load funcion" so that the image is passed
                to the image tag */

            var reader = new FileReader();
            reader.onload = function(){
                var dataURL = reader.result;
                var output = document.querySelector(DOMstrings.img_id).src = reader.result;
          };
          reader.readAsDataURL(inputfiles[0]);
        }

    }

    function ctrFilter(){
        // Get filter
         var filtertxt = document.querySelector(DOMstrings.filtersel).value;

         // Process image
         proc_image(filtertxt);
     }


    function proc_image(filter){

        var imgDOM = document.querySelector(DOMstrings.img_id);

        if(imgDOM.src.length > 0){
            var img = new SimpleImage(document.querySelector(DOMstrings.img_id).src);
            var imgnew;

            // Apply filter
            switch (filter){
                case "Red":
                    imgnew = redFilter(img);
                    break;

                case "Green":
                    imgnew = greenFilter(img);
                    break;

                case "Purple":
                    imgnew = purpleFilter(img);
                    break;

                case "Gray":
                    imgnew = grayScale(img);
                    break;

                case "French":
                    imgnew = FrenchFlag(img);

                    break;

                case "Hungary":
                    imgnew = HungaryFlag(img);
                    break;

                case "Japan":
                    imgnew = JapanFlag(img);
                    break;

                case "Rainbow":
                    imgnew = Rainbow(img);
                    break;

                case "Blur":
                    console.log("Blur");
                    imgnew = Blur(img);
                    break;

            }

            imgnew.drawTo(document.querySelector(DOMstrings.canvas));

            // Get work in


        }
        else {
            alert("Image not loaded. Please load image.")
        }

    }

    function redFilter(image){
        console.log("Red");
        for (var pxl of image.values()){
            makePxlRed(pxl);
        }
        return image;
    }

    function greenFilter(image){
        for (var pxl of image.values()){
            makePxlGreen(pxl);
        }
        return image;

    }

    function purpleFilter(image){
        for (var pxl of image.values()){
            makePxlPurple(pxl);
        }
        return image;

    }

    function grayScale(image){
        for (var pxl of image.values()){
            makePxlGray(pxl);
        }
        return image;

    }

    function FrenchFlag(image){
        for(var pxl of image.values()){

          if(pxl.getX() < image.getWidth() / 3){
           makePxlRed(pxl);
          }
          else if (pxl.getX() >= image.getWidth() / 3 * 2){
            makePxlBlue(pxl);
          }
          else{
              makePxlGray(pxl);
          }
        }

        return image;

    }

    function HungaryFlag(image){
        for(var pxl of image.values()){

          if(pxl.getY() < image.getHeight() / 3){
            makePxlRed(pxl);
          }
          else if (pxl.getY() >= image.getHeight() / 3 * 2){
           makePxlGreen(pxl);
          }
          else{
            makePxlGray(pxl);
          }
        }
        return image;

    }

    function JapanFlag(image){
        var radius = 0.35 * Math.min(image.getWidth(),image.getHeight());

        for(var pxl of image.values()){
          if(Math.pow(pxl.getX() - image.getWidth() / 2,2) + Math.pow(pxl.getY() - image.getHeight() / 2,2) < Math.pow(radius,2)){
            makePxlRed(pxl);
          }
          else{
            makePxlGray(pxl);
          }
      }
      return image;

    }

    function Rainbow(image){
        for(var pxl of image.values()){
          if(pxl.getY() < image.getHeight() / 7){
            makePxlRed(pxl);
          }
          else if (pxl.getY() >= image.getHeight() / 7 && pxl.getY() < image.getHeight() / 7 * 2){
            makePxlOrange(pxl);
          }
          else if (pxl.getY() >= image.getHeight() / 7 * 2 && pxl.getY() < image.getHeight() / 7 * 3){
            makePxlYellow(pxl);
          }
          else if (pxl.getY() >= image.getHeight() / 7 * 3 && pxl.getY() < image.getHeight() / 7 * 4){
            makePxlGreen(pxl);
          }
           else if (pxl.getY() >= image.getHeight() / 7 * 4 && pxl.getY() < image.getHeight() / 7 * 5){
            makePxlBlue(pxl);
          }
          else if (pxl.getY() >= image.getHeight() / 7 * 5 && pxl.getY() < image.getHeight() / 7 * 6){
            makePxlPurple(pxl);
          }
          else{
            makePxlIndigo(pxl);
          }
        }

        return image;

    }

    function Blur(image){
        var radius;
        var angle;
        var xNew;
        var yNew;
        var imgBlur = new SimpleImage(image);

        for (var pxl of image.values()){
            if (Math.random() > 0.5){
                radius = 10*Math.random();
                angle = 360 * Math.random();
                xNew = Math.min(Math.max(pxl.getX() + Math.round(radius * Math.cos(angle)), 0), image.getWidth() - 1);
                yNew = Math.min(Math.max(pxl.getY() + Math.round(radius * Math.sin(angle)), 0), image.getHeight() - 1);
                imgBlur.setPixel(pxl.getX(), pxl.getY(), image.getPixel(xNew, yNew));
            }
            else{
                imgBlur.setPixel(pxl.getX(),pxl.getY(),pxl);
            }
        }

        return imgBlur;

    }

    // Pixel coloration functions

    function makePxlRed(pixel){
      // Make a pixel red as per algorithm specifications
        var pxlAvg = Math.round((pixel.getRed() + pixel.getBlue() + pixel.getGreen()) / 3);

        if(pxlAvg < 128){
          pixel.setRed(pxlAvg * 2);
          pixel.setBlue(0);
          pixel.setGreen(0);
        }
        else{
          pixel.setRed(255);
          pixel.setBlue(pxlAvg * 2 - 255);
          pixel.setGreen(pxlAvg * 2 - 255);
        }
    }

    function makePxlOrange(pixel){
      // Make a pixel red as per algorithm specifications
        var pxlAvg = Math.round((pixel.getRed() + pixel.getBlue() + pixel.getGreen()) / 3);

        if(pxlAvg < 128){
          pixel.setRed(pxlAvg * 2);
          pixel.setBlue(0);
          pixel.setGreen(pxlAvg * 0.8);
        }
        else{
          pixel.setRed(255);
          pixel.setBlue(pxlAvg * 2 - 255);
          pixel.setGreen(pxlAvg * 1.2 - 51);
        }
    }

    function makePxlYellow(pixel){
      // Make a pixel red as per algorithm specifications
        var pxlAvg = Math.round((pixel.getRed() + pixel.getBlue() + pixel.getGreen()) / 3);

        if(pxlAvg < 128){
          pixel.setRed(pxlAvg * 2);
          pixel.setBlue(0);
          pixel.setGreen(pxlAvg * 2);
        }
        else{
          pixel.setRed(255);
          pixel.setBlue(pxlAvg * 2 - 255);
          pixel.setGreen(255);
        }
    }

    function makePxlGreen(pixel){
      // Make a pixel red as per algorithm specifications
        var pxlAvg = Math.round((pixel.getRed() + pixel.getBlue() + pixel.getGreen()) / 3);

         if(pxlAvg < 128){
          pixel.setRed(0);
          pixel.setBlue(0);
          pixel.setGreen(pxlAvg * 2);
        }
        else{
          pixel.setRed(pxlAvg * 2 - 255);
          pixel.setBlue(pxlAvg * 2 - 255);
          pixel.setGreen(255);
        }
    }

    function makePxlBlue(pixel){
      // Make a pixel red as per algorithm specifications
        var pxlAvg = Math.round((pixel.getRed() + pixel.getBlue() + pixel.getGreen()) / 3);

        if(pxlAvg < 128){
           pixel.setRed(0);
           pixel.setBlue(pxlAvg * 2);
           pixel.setGreen(0);
        }
        else{
          pixel.setRed(pxlAvg * 2 - 255);
          pixel.setBlue(255);
          pixel.setGreen(pxlAvg * 2 - 255);
        }
    }

    function makePxlPurple(pixel){
      // Make a pixel red as per algorithm specifications
        var pxlAvg = Math.round((pixel.getRed() + pixel.getBlue() + pixel.getGreen()) / 3);

        if(pxlAvg < 128){
           pixel.setRed(0.8 * pxlAvg);
           pixel.setBlue(pxlAvg * 2);
           pixel.setGreen(0);
        }
        else{
          pixel.setRed(pxlAvg * 1.2 - 51);
          pixel.setBlue(255);
          pixel.setGreen(pxlAvg * 2 - 255);
        }
    }

    function makePxlIndigo(pixel){
      // Make a pixel red as per algorithm specifications
        var pxlAvg = Math.round((pixel.getRed() + pixel.getBlue() + pixel.getGreen()) / 3);

        if(pxlAvg < 128){
           pixel.setRed(1.6 * pxlAvg);
           pixel.setBlue(1.6 * pxlAvg);
           pixel.setGreen(0);
        }
        else{
          pixel.setRed(pxlAvg * 0.4 + 153);
          pixel.setBlue(pxlAvg * 0.4 + 153);
          pixel.setGreen(pxlAvg * 2 - 255);
        }
    }

    function makePxlGray(pixel){
       var pxlAvg = Math.round((pixel.getRed() + pixel.getBlue() + pixel.getGreen()) / 3);

          pixel.setRed(pxlAvg);
          pixel.setBlue(pxlAvg);
          pixel.setGreen(pxlAvg);
    }

    return {
        init: function(){
            initialize();
            console.log("Controller initialized...")
        }
    }

}());

controller.init();
