// Get input from financial graph page and generate graph

function GenGraph(){

    var ldstart = document.getElementById("BeginDate").value;
	var lcCompany = document.getElementById("Company").value;
    var ldend = document.getElementById("EndDate").value;

    alert('Chart user configuration currently unavailble. Input boxes are currently placeholders.');

    return
}
